/* 
 *  ProtoBot.cpp - This is the library for the ProtoBot version 0.3
 *
 * For more information, visit https://theprotobotproject.wordpress.com
 * You can also visit the github, at https://github.com/Bobcatmodder/ProtoBots
 * 
 * Written by Jacob Field
 * Licensed under the MIT License, see license.txt for more details
 */
 
#include <arduino.h>
#include "ProtoBot.h"


//Variables, definitions, ect 


//Motor control pin definitions
#define ML1 5
#define ML2 6
#define MR1 10
#define MR2 11

//Sensor pin definitions
#define BL 3
#define BR 2
#define IR A0
#define IL A1

boolean pressedLeft();
boolean pressedRight();


//Public methods 


//WaitForStart and Setup functions

void ProtoBot::setupRobot(){
  //Setup the output pins for the motor
  pinMode(ML1, OUTPUT);
  pinMode(ML2, OUTPUT);
  pinMode(MR1, OUTPUT);
  pinMode(MR2, OUTPUT);

  //Setup the input pins for the bump sensors
  pinMode(BL, INPUT);
  pinMode(BR, INPUT);
}

void ProtoBot::waitForBump(){
  //Loops till the left touch sensor is pressed for easier programming
  while(!digitalRead(BL)){//This was originally !pressedLeft but they seem to be returning inverted values for whatever reason
    delay(100);
  }
  delay(512);
}

//Functions for testing if the touch sensor has been pressed

boolean ProtoBot::pressedLeft(){
  boolean val = digitalRead(BL);
  if (val == 1){return true;}
  else if (val == 0){return false;}
}

boolean ProtoBot::pressedRight(){
  boolean val = digitalRead(BR);
  if (val == 1){return true;}
  else if (val == 0){return false;}
}

//Functions for returing IR sensor values

int ProtoBot::leftInfrared(){
  return analogRead(IL);
}

int ProtoBot::rightInfrared(){
  return analogRead(IR);
}

//Fuctions for motor speed/direction control

void ProtoBot::setLeft(int motSpeed){
  if(motSpeed < 0){
    motSpeed = map(motSpeed, 0, -255, 0, 255);
    analogWrite(ML2, motSpeed);
    digitalWrite(ML1, LOW);
  } else {
    analogWrite(ML1, motSpeed);
    digitalWrite(ML2, LOW);
  }
}

void ProtoBot::setRight(int motSpeed){
  if(motSpeed < 0){
    motSpeed = map(motSpeed, 0, -255, 0, 255);
    analogWrite(MR2, motSpeed);
    digitalWrite(MR1, LOW);
  } else {
    analogWrite(MR1, motSpeed);
    digitalWrite(MR2, LOW);
  }
}
 
 