This library is intended for use with the ProtoBots.

Visit https://theprotobotproject.wordpress.com to learn more
If you want the design files, and to find the latest version of the libary, visit: https://github.com/Bobcatmodder/ProtoBots