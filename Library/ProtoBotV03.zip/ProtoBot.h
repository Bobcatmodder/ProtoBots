/* 
 *  ProtoBot.h - This is a library for the ProtoBot version 0.3
 *
 * For more information, visit https://theprotobotproject.wordpress.com
 * You can also visit the github, at https://github.com/Bobcatmodder/ProtoBots
 * 
 * Written by Jacob Field
 * Licensed under the MIT License, see license.txt for more details
 */
 
#ifndef ProtoBot_h
#define ProtoBot_h

#include <arduino.h>

class ProtoBot
{
public:
	boolean pressedLeft(); //Will test to see if the left bumper has been pressed
	boolean pressedRight();	//Will test to see if the right bumper has been pressed
	
	int leftInfrared(); //Will return the analog value from the left IR sensor
	int rightInfrared(); //Will return the value from the right IR sensor
	
	void setLeft(int motSpeed); //Will set the Left motor speed
	void setRight(int motSpeed); //Will set the Right motor speed
	
	void setupRobot(); //Sets up the input/output pins
	void waitForBump(); //For running in the setup, waits until the left bumper is pressed 
	
};

#endif